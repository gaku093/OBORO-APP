// Monta a pasta www/ (o que vai dentro do app) a partir dos arquivos do site.
// O site em si NÃO é alterado: só a cópia que vai para o app.
//  - copia index.html, css/, js/, assets/
//  - embute o SDK do Supabase (o app não depende de CDN para abrir)
//  - ajusta a CSP e o topo da tela (barra de status do Android)
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const www = path.join(root, "www");

function fail(msg) { console.error("ERRO: " + msg); process.exit(1); }

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(www, { recursive: true });

for (const item of ["index.html", "css", "js", "assets"]) {
  const src = path.join(root, item);
  if (!fs.existsSync(src)) fail(`não achei "${item}" na raiz do projeto (o app precisa estar junto do site)`);
  fs.cpSync(src, path.join(www, item), { recursive: true });
}

// SDK do Supabase local
const sdk = path.join(root, "node_modules", "@supabase", "supabase-js", "dist", "umd", "supabase.js");
if (!fs.existsSync(sdk)) fail("SDK do Supabase não encontrado — rode `npm install` antes.");
fs.mkdirSync(path.join(www, "js", "vendor"), { recursive: true });
fs.copyFileSync(sdk, path.join(www, "js", "vendor", "supabase.js"));

let html = fs.readFileSync(path.join(www, "index.html"), "utf8");

// 1) trocar o <script> do jsDelivr pelo arquivo local
const before = html;
html = html.replace(
  /<script src="https:\/\/cdn\.jsdelivr\.net\/npm\/@supabase\/supabase-js@[^"]+"[^>]*><\/script>/,
  '<script src="js/vendor/supabase.js"></script>'
);
if (html === before) fail("não achei a tag <script> do Supabase no index.html (o site mudou?).");

// 2) CSP: não precisa mais liberar o jsDelivr
html = html.replace("script-src 'self' https://cdn.jsdelivr.net;", "script-src 'self';");

// 3) respeitar a barra de status do Android
// (a CSP não aceita <style> inline, então vai em um arquivo CSS)
fs.writeFileSync(path.join(www, "css", "android.css"),
  "#screen{padding-top:env(safe-area-inset-top,0px)}\n");
html = html.replace("</head>", '<link rel="stylesheet" href="css/android.css">\n</head>');

fs.writeFileSync(path.join(www, "index.html"), html);
console.log("www/ pronto:", fs.readdirSync(www).join(", "));
