# Oboro — app Android

Este pacote transforma o site Oboro (repositório `gaku093/oboro-app`) em um app Android
(Capacitor). O site continua igual; o app usa os mesmos arquivos e o mesmo Supabase.

## Como gerar o APK (sem computador)

1. No repositório `oboro-app` do GitHub, envie estes arquivos/pastas **para a raiz**,
   junto de `index.html`, `css/`, `js/`, `assets/`:
   - `package.json`
   - `capacitor.config.json`
   - `.gitignore`
   - `scripts/prepare-web.js`
   - `resources/` (ícones e tela de abertura)
   - `.github/workflows/build-apk.yml`
2. O GitHub começa a compilar sozinho (aba **Actions** → "Gerar APK do Oboro", ~5–8 min).
   Dá para rodar manualmente em **Run workflow**.
3. Quando terminar, abra a aba **Releases** do repositório e baixe **Oboro.apk**
   no celular. Instale (permita "instalar apps desconhecidos" para o navegador).

## Para rodar em um computador (opcional)

    npm install
    npm run prepare:web
    npx cap add android
    npx cap sync android
    npx cap open android      # abre no Android Studio

## Observações
- O APK gerado é "debug" (instala direto, serve para uso e testes). Para publicar na
  Play Store é preciso um build assinado (release) — posso preparar depois.
- O app precisa de internet (os quadrinhos e contas ficam no Supabase).
- Links de confirmação/recuperação de senha abrem o site (`SITE_URL` em `js/config.js`).
- Pacote de app: `br.com.oboro.app` (muda em `capacitor.config.json`).
